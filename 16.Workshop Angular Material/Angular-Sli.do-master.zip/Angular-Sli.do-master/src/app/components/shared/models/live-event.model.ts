export class SlidoEvent {
  id: string;
  code: string;
  questions: string[];
}