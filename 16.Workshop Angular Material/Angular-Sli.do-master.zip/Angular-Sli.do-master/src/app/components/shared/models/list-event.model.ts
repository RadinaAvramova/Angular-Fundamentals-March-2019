export interface ListSlidoEvent {
  code: string;
  createdOn: Date;
  expiresOn: Date;
}