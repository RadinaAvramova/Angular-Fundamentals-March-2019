export interface CreateSlidoEvent {
  code: string;
  expiresOn: Date;
  createdOn: Date;
}