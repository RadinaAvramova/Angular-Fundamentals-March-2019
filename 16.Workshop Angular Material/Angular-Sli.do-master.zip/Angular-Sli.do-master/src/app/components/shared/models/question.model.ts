export class Question {
  createdOn: Date;
  text: string;
  eventId: string;
  username: string;
}